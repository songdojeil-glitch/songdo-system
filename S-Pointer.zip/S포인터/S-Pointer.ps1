﻿<#
  ═════════════════════════════════════════════════════════════════
   S포인터 v1.4 (2026-10-11) — 송도제일 SJRWS (화면 녹화용 포인터 · 판서)
   화면 녹화용 포인터 · 판서 — 웹·네이버부동산·엑셀·카카오맵 등 PC 화면 어디 위에나 그린다
   · 조작 모드: 화면을 그대로 누를 수 있고 커서 강조 링(누르면 작아짐)이 따라다닌다
   · 판서 모드: 펜(필압) · 형광펜 · 직선(밑줄) · 화살표 · 곡선 화살표(위로 휨 · 아래로 휨) · 사각형 · 원 · 손별표 · 지우개
   · v1.1 ⏳ 프레젠테이션 모드 — 그린 것이 0.5S·1S·2S·3S 뒤 저절로 사라짐 · ✨ 네온 — 그린 선이 제 색으로 빛남(밝은 심지 + 번지는 빛)
   · v1.2 ⤴⤵ 곡선 화살표(위 · 아래로 휜 곡선) · ☆ 손별표(펜으로 쓱 그린 듯한 한붓 별 — 끌어서 크기, 톡 누르면 기본 크기) · 프레젠테이션 1S 추가(5S 뺌)
   · v1.3 프레젠테이션 0.5S · 1S · 2S · 3S (4S 뺌) · 🖱 왼쪽 단추 빠르게 4번 클릭 = S포인터 끝내기 (판서·조작 어디서나, 도구줄 위 클릭은 제외)
   · v1.4 🖱 꺼져 있을 때 오른쪽 단추 빠르게 3번 클릭 = 켜기 (S-Pointer-Watch.ps1 감시 · 시작프로그램 「S포인터 오른쪽3번」 · 트레이 메뉴에서 켜고 끔)
   · 마우스 · 터치 · Windows 펜(갤럭시북 S펜 · 서피스 펜 · 와콤) — Windows Ink 그대로 (필압)
   · 오른쪽 두 번 클릭 = 판서 ↔ 조작 · 판서 중 왼쪽 두 번 클릭 = 작은 원으로 접기 (끌어서 옮기고 누르면 펼침)
   · 단축키(어디서나): Ctrl+Shift+X 판서↔조작 · Ctrl+Shift+Z 실행 취소 · Ctrl+Shift+C 전체 지우기
                      Ctrl+Shift+M 도구줄을 마우스 자리로 · Ctrl+Shift+Q 끝내기 · (판서 중) Esc 조작으로
   · 왼쪽 빠르게 4번 클릭(같은 자리) = 끝내기
   · 끝내기: 도구줄 ✕ · Ctrl+Shift+Q · 왼쪽 4번 클릭 · 작업 표시줄 오른쪽 트레이 아이콘 → 끝내기 · SJRWS 도구 → 🖊 포인터 「■ 끄기」
   · 켜기: 오른쪽 3번 클릭(감시를 켰을 때) · 바탕화면 「S포인터」 · SJRWS 도구 → 🖊 포인터 「▶ 켜기」(spointer:// — 설치 파일이 등록)
   · 설정은 %APPDATA%\S-Pointer\cfg.json, PNG 저장은 사진\S포인터
  ═════════════════════════════════════════════════════════════════
#>
Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase, System.Windows.Forms, System.Drawing

# 한 번만 켜지게
$script:FlagDir = Join-Path $env:APPDATA 'S-Pointer'
if(-not (Test-Path $script:FlagDir)){ New-Item -ItemType Directory -Path $script:FlagDir | Out-Null }
$script:Mtx = New-Object System.Threading.Mutex($false, 'Local\S_Pointer_SJRWS')
if(-not $script:Mtx.WaitOne(0)){ Set-Content -Path (Join-Path $script:FlagDir 'show.flag') -Value '1'; exit }   # 이미 켜져 있으면 도구줄만 불러온다
Remove-Item (Join-Path $script:FlagDir 'quit.flag') -ErrorAction SilentlyContinue

Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class MkWin {
  [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X; public int Y; }
  [DllImport("user32.dll")] public static extern int GetWindowLong(IntPtr h, int i);
  [DllImport("user32.dll")] public static extern int SetWindowLong(IntPtr h, int i, int v);
  [DllImport("user32.dll")] public static extern short GetAsyncKeyState(int k);
  [DllImport("user32.dll")] public static extern bool GetCursorPos(out POINT p);
  const int EX = -20, TRANSPARENT = 0x20, LAYERED = 0x80000, TOOL = 0x80, NOACT = 0x08000000;
  public static void ClickThrough(IntPtr h, bool on) { int ex = GetWindowLong(h, EX) | LAYERED | TOOL; if (on) ex |= TRANSPARENT; else ex &= ~TRANSPARENT; SetWindowLong(h, EX, ex); }
  public static void NoActivate(IntPtr h) { SetWindowLong(h, EX, GetWindowLong(h, EX) | NOACT | TOOL); }
  public static bool Down(int k) { return (GetAsyncKeyState(k) & 0x8000) != 0; }
  public static int[] Cursor() { POINT p; GetCursorPos(out p); return new int[] { p.X, p.Y }; }
}
'@

# ── 설정 ──
$script:CfgDir = Join-Path $env:APPDATA 'S-Pointer'
$script:CfgFile = Join-Path $script:CfgDir 'cfg.json'
$script:Cfg = @{ color = '#FFFF3B3B'; w = 5; ring = $true; ringColor = '#FFFFD60A'; fade = $false; fadeSec = 3; neon = $false; tool = 'pen'; bx = -99999; by = -99999; mx = -99999; my = -99999 }
if(Test-Path $script:CfgFile){ try{ $j = Get-Content $script:CfgFile -Raw -Encoding UTF8 | ConvertFrom-Json; foreach($p in $j.PSObject.Properties){ $script:Cfg[$p.Name] = $p.Value } }catch{} }
$script:Cfg.fadeSec = [Math]::Max(0.5, [Math]::Min(3, [double]$script:Cfg.fadeSec))   # v1.3 — 0.5S~3S (예전 4S·5S 는 3S 로)
function Save-Cfg { try{ if(-not (Test-Path $script:CfgDir)){ New-Item -ItemType Directory -Path $script:CfgDir | Out-Null }; ($script:Cfg | ConvertTo-Json) | Set-Content -Path $script:CfgFile -Encoding UTF8 }catch{} }

$COLORS = @('#FFFF3B3B', '#FFFF9F1C', '#FFFFE14D', '#FF2EE59D', '#FF22D3EE', '#FF3B82F6', '#FFC084FC', '#FFFF4FD8', '#FFFFFFFF', '#FF111111')
function To-Color([string]$s){ return [System.Windows.Media.ColorConverter]::ConvertFromString($s) }
function To-Brush([string]$s){ return New-Object System.Windows.Media.SolidColorBrush (To-Color $s) }

# ── 덮개(전체 화면 · 투명) ──
$ovXaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="S포인터" WindowStyle="None" AllowsTransparency="True" Background="Transparent" Topmost="True" ShowInTaskbar="False" ResizeMode="NoResize" ShowActivated="False">
  <Grid>
    <!-- ✨ 네온 — 같은 획을 흐리게 두 겹 깔아 제 색으로 번지게 (보이기만, 입력은 위 InkCanvas) -->
    <InkPresenter x:Name="GlowW" IsHitTestVisible="False" Visibility="Collapsed" Opacity="0.95"><InkPresenter.Effect><BlurEffect Radius="26"/></InkPresenter.Effect></InkPresenter>
    <InkPresenter x:Name="GlowN" IsHitTestVisible="False" Visibility="Collapsed"><InkPresenter.Effect><BlurEffect Radius="9"/></InkPresenter.Effect></InkPresenter>
    <InkCanvas x:Name="Ink" Background="Transparent"/>
  </Grid>
</Window>
'@
$ov = [Windows.Markup.XamlReader]::Parse($ovXaml)
$Ink = $ov.FindName('Ink'); $GlowW = $ov.FindName('GlowW'); $GlowN = $ov.FindName('GlowN')
$GlowW.Strokes = $Ink.Strokes; $GlowN.Strokes = $Ink.Strokes   # 같은 획 묶음을 함께 본다
$ov.Left = [System.Windows.SystemParameters]::VirtualScreenLeft; $ov.Top = [System.Windows.SystemParameters]::VirtualScreenTop
$ov.Width = [System.Windows.SystemParameters]::VirtualScreenWidth; $ov.Height = [System.Windows.SystemParameters]::VirtualScreenHeight
$script:HitBrush = To-Brush '#01FFFFFF'   # 판서 때 — 거의 투명하지만 펜·마우스를 받는다

# ── 도구줄 ──
$tbXaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="S포인터 도구" WindowStyle="None" AllowsTransparency="True" Background="Transparent" Topmost="True" ShowInTaskbar="False" ResizeMode="NoResize" SizeToContent="WidthAndHeight" ShowActivated="False">
  <Window.Resources>
    <Style x:Key="B" TargetType="Button">
      <Setter Property="Foreground" Value="#FFE9ECF5"/>
      <Setter Property="Background" Value="#18FFFFFF"/>
      <Setter Property="FontFamily" Value="Malgun Gothic"/>
      <Setter Property="FontSize" Value="12.5"/>
      <Setter Property="FontWeight" Value="Bold"/>
      <Setter Property="Height" Value="34"/>
      <Setter Property="MinWidth" Value="34"/>
      <Setter Property="Margin" Value="2"/>
      <Setter Property="Padding" Value="9,0"/>
      <Setter Property="Cursor" Value="Hand"/>
      <Setter Property="Focusable" Value="False"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="Button">
            <Border x:Name="Bd" CornerRadius="10" Background="{TemplateBinding Background}" BorderBrush="#00FFFFFF" BorderThickness="1" Padding="{TemplateBinding Padding}">
              <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="IsMouseOver" Value="True"><Setter TargetName="Bd" Property="BorderBrush" Value="#77FFFFFF"/></Trigger>
              <Trigger Property="IsPressed" Value="True"><Setter TargetName="Bd" Property="Opacity" Value="0.7"/></Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>
    <Style x:Key="Chip" TargetType="Button">
      <Setter Property="Width" Value="24"/>
      <Setter Property="Height" Value="24"/>
      <Setter Property="Margin" Value="2,0"/>
      <Setter Property="Cursor" Value="Hand"/>
      <Setter Property="Focusable" Value="False"/>
      <Setter Property="BorderBrush" Value="#55FFFFFF"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="Button">
            <Grid>
              <Ellipse Fill="{TemplateBinding Background}" Stroke="{TemplateBinding BorderBrush}" StrokeThickness="2"/>
            </Grid>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>
  </Window.Resources>
  <Border CornerRadius="18" Padding="8,7" BorderBrush="#22FFFFFF" BorderThickness="1" Margin="14">
    <Border.Background>
      <LinearGradientBrush StartPoint="0,0" EndPoint="0,1">
        <GradientStop Color="#F21C1E2C" Offset="0"/>
        <GradientStop Color="#F20E0F18" Offset="1"/>
      </LinearGradientBrush>
    </Border.Background>
    <Border.Effect><DropShadowEffect BlurRadius="24" ShadowDepth="6" Opacity="0.55" Color="Black"/></Border.Effect>
    <StackPanel>
      <WrapPanel x:Name="Row" Orientation="Horizontal" VerticalAlignment="Center">
        <TextBlock x:Name="Grip" Text="⋮⋮" Foreground="#66FFFFFF" FontSize="14" VerticalAlignment="Center" Margin="2,0,4,0" Cursor="SizeAll" ToolTip="끌어서 옮기기"/>
        <TextBlock VerticalAlignment="Center" Margin="0,0,8,0" FontFamily="Malgun Gothic" FontWeight="Black" FontSize="13">
          <Run Text="S" Foreground="#FFFF4FD8"/><Run Text="포인터" Foreground="White"/>
        </TextBlock>
        <Button x:Name="BMode" Style="{StaticResource B}" Content="판서" ToolTip="판서 ↔ 조작 (오른쪽 두 번 클릭 · Ctrl+Shift+X)" MinWidth="70"/>
        <Rectangle Width="1" Height="24" Margin="5,0" Fill="#22FFFFFF"/>
        <Button x:Name="T_pen" Tag="pen" Style="{StaticResource B}" Content="✎ 펜" ToolTip="펜 — Windows 펜은 필압"/>
        <Button x:Name="T_hl" Tag="hl" Style="{StaticResource B}" Content="형광펜"/>
        <Button x:Name="T_line" Tag="line" Style="{StaticResource B}" Content="／ 직선" ToolTip="직선 · 밑줄"/>
        <Button x:Name="T_arrow" Tag="arrow" Style="{StaticResource B}" Content="➜ 화살표"/>
        <Button x:Name="T_curveU" Tag="curveU" Style="{StaticResource B}" Content="⤴ 위 곡선" ToolTip="곡선 화살표 — 위로 휘어 넘어감 (끌어서 시작 → 끝)"/>
        <Button x:Name="T_curveD" Tag="curveD" Style="{StaticResource B}" Content="⤵ 아래 곡선" ToolTip="곡선 화살표 — 아래로 휘어 넘어감 (끌어서 시작 → 끝)"/>
        <Button x:Name="T_rect" Tag="rect" Style="{StaticResource B}" Content="▭ 사각"/>
        <Button x:Name="T_oval" Tag="oval" Style="{StaticResource B}" Content="◯ 원"/>
        <Button x:Name="T_star" Tag="star" Style="{StaticResource B}" Content="☆ 별표" ToolTip="펜으로 쓱 그린 듯한 별 — 끌어서 크기 · 톡 누르면 기본 크기"/>
        <Button x:Name="T_erase" Tag="erase" Style="{StaticResource B}" Content="지우개" ToolTip="그린 것을 하나씩 지우기"/>
        <Rectangle Width="1" Height="24" Margin="5,0" Fill="#22FFFFFF"/>
        <StackPanel x:Name="Chips" Orientation="Horizontal" VerticalAlignment="Center"/>
        <Button x:Name="BAll" Style="{StaticResource B}" Content="전체 색상" ToolTip="모든 색에서 고르기"/>
        <Rectangle Width="1" Height="24" Margin="5,0" Fill="#22FFFFFF"/>
        <TextBlock x:Name="WTxt" Text="굵기 5" Foreground="#FFAAB0C0" FontFamily="Malgun Gothic" FontSize="11.5" VerticalAlignment="Center" Margin="2,0,4,0" Width="40"/>
        <Slider x:Name="SW" Minimum="1" Maximum="24" Width="96" VerticalAlignment="Center" IsSnapToTickEnabled="True" TickFrequency="1" Focusable="False"/>
        <Rectangle Width="1" Height="24" Margin="5,0" Fill="#22FFFFFF"/>
        <Button x:Name="BRing" Style="{StaticResource B}" Content="◎ 커서 강조"/>
        <Button x:Name="BRingC" Style="{StaticResource B}" ToolTip="커서 강조 색상">
          <StackPanel Orientation="Horizontal"><Ellipse x:Name="RingDot" Width="12" Height="12" Margin="0,0,5,0"/><TextBlock Text="커서 색상"/></StackPanel>
        </Button>
        <Button x:Name="BNeon" Style="{StaticResource B}" Content="✨ 네온" ToolTip="그린 선이 제 색으로 빛나게 (네온사인)"/>
        <Button x:Name="BFade" Style="{StaticResource B}" Content="⏳ 프레젠테이션" ToolTip="프레젠테이션 모드 — 강조한 판서가 정한 시간 뒤 저절로 사라짐"/>
        <StackPanel x:Name="FadeSecs" Orientation="Horizontal" VerticalAlignment="Center" Margin="0,0,2,0">
          <Button Tag="0.5" Style="{StaticResource B}" Content="0.5S" MinWidth="30" Padding="5,0" Margin="1,2"/>
          <Button Tag="1" Style="{StaticResource B}" Content="1S" MinWidth="30" Padding="5,0" Margin="1,2"/>
          <Button Tag="2" Style="{StaticResource B}" Content="2S" MinWidth="30" Padding="5,0" Margin="1,2"/>
          <Button Tag="3" Style="{StaticResource B}" Content="3S" MinWidth="30" Padding="5,0" Margin="1,2"/>
        </StackPanel>
        <Button x:Name="BUndo" Style="{StaticResource B}" Content="↶ 취소" ToolTip="실행 취소 (Ctrl+Shift+Z)"/>
        <Button x:Name="BClear" Style="{StaticResource B}" Content="전체 지우기" ToolTip="Ctrl+Shift+C"/>
        <Button x:Name="BPng" Style="{StaticResource B}" Content="PNG 저장" ToolTip="지금 화면을 사진\S포인터 에 저장"/>
        <Button x:Name="BMin" Style="{StaticResource B}" Content="⤡" ToolTip="작은 원으로 접기 (판서 중 왼쪽 두 번 클릭)"/>
        <Button x:Name="BExit" Style="{StaticResource B}" Content="✕" Background="#33FF5050" Foreground="#FFFFB3B3" ToolTip="끝내기 (Ctrl+Shift+Q)"/>
      </WrapPanel>
      <TextBlock x:Name="Tip" Foreground="#FF8A90A5" FontFamily="Malgun Gothic" FontSize="11" Margin="6,4,4,0" Text="오른쪽 두 번 클릭 = 판서 ↔ 조작 · 판서 중 왼쪽 두 번 클릭 = 작게 · 왼쪽 네 번 클릭 = 끝내기"/>
    </StackPanel>
  </Border>
</Window>
'@
$tb = [Windows.Markup.XamlReader]::Parse($tbXaml)
foreach($n in 'Row','Grip','BMode','Chips','BAll','WTxt','SW','BRing','BRingC','RingDot','BNeon','BFade','FadeSecs','BUndo','BClear','BPng','BMin','BExit','Tip'){ Set-Variable -Name $n -Value $tb.FindName($n) -Scope Script }
$script:ToolBtns = @{}; foreach($t in 'pen','hl','line','arrow','curveU','curveD','rect','oval','star','erase'){ $script:ToolBtns[$t] = $tb.FindName('T_' + $t) }
$Row.MaxWidth = [Math]::Max(600, [System.Windows.SystemParameters]::PrimaryScreenWidth - 80)

# ── 작은 원 ──
$miniXaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="S포인터" WindowStyle="None" AllowsTransparency="True" Background="Transparent" Topmost="True" ShowInTaskbar="False" ResizeMode="NoResize" Width="76" Height="76" ShowActivated="False">
  <Grid Cursor="Hand" ToolTip="끌어서 옮기기 · 누르면 도구줄">
    <Ellipse x:Name="Glow" Width="64" Height="64" StrokeThickness="4">
      <Ellipse.Effect><DropShadowEffect BlurRadius="18" ShadowDepth="0" Opacity="0.9"/></Ellipse.Effect>
      <Ellipse.Fill>
        <RadialGradientBrush GradientOrigin="0.35,0.3"><GradientStop Color="#FF3A3D55" Offset="0"/><GradientStop Color="#FF12131D" Offset="1"/></RadialGradientBrush>
      </Ellipse.Fill>
    </Ellipse>
    <TextBlock x:Name="MiniTx" Text="S" Foreground="White" FontFamily="Malgun Gothic" FontWeight="Black" FontSize="26" HorizontalAlignment="Center" VerticalAlignment="Center"/>
  </Grid>
</Window>
'@
$mini = [Windows.Markup.XamlReader]::Parse($miniXaml)
$Glow = $mini.FindName('Glow'); $GlowFx = $Glow.Effect; $MiniTx = $mini.FindName('MiniTx')

# ── 커서 강조 링 (클릭이 그대로 통과) ──
$ringXaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="S ring" WindowStyle="None" AllowsTransparency="True" Background="Transparent" Topmost="True" ShowInTaskbar="False" ResizeMode="NoResize" Width="64" Height="64" ShowActivated="False" IsHitTestVisible="False">
  <Grid><Ellipse x:Name="R" Width="44" Height="44" StrokeThickness="3"><Ellipse.Effect><DropShadowEffect BlurRadius="12" ShadowDepth="0" Opacity="0.8"/></Ellipse.Effect></Ellipse></Grid>
</Window>
'@
$ring = [Windows.Markup.XamlReader]::Parse($ringXaml)
$RingE = $ring.FindName('R'); $RingFx = $RingE.Effect


# ── 상태 ──
$script:Draw = $false; $script:Min = $false; $script:Mute = $false
$script:Hist = New-Object System.Collections.ArrayList
$script:Born = @{}          # 그린 때 (프레젠테이션 모드)
$script:Shape = $null; $script:ShapeStart = $null; $script:ShapeSeed = 1; $script:TapStar = $null
$SHAPES = @('line','arrow','curveU','curveD','rect','oval','star')   # 끌어서 그리는 도형
$ACT = New-Object System.Windows.Media.LinearGradientBrush((To-Color '#FFFF4FD8'), (To-Color '#FFC026D3'), 90)
$ACT2 = New-Object System.Windows.Media.LinearGradientBrush((To-Color '#FF22D3EE'), (To-Color '#FF0891B2'), 90)
$IDLE = To-Brush '#18FFFFFF'

function Say([string]$t){ $Tip.Text = $t; $Tip.Foreground = To-Brush '#FFFFD6F5'; $script:TipAt = [DateTime]::Now }
function Hwnd($w){ return (New-Object System.Windows.Interop.WindowInteropHelper($w)).Handle }

function Make-DA {
  $da = New-Object System.Windows.Ink.DrawingAttributes
  $da.Color = To-Color $script:Cfg.color; $da.FitToCurve = $true; $da.IgnorePressure = $false
  $w = [double]$script:Cfg.w
  if($script:Cfg.tool -eq 'hl'){ $da.IsHighlighter = $true; $da.StylusTip = 'Rectangle'; $da.Width = $w * 3 + 10; $da.Height = $w * 3 + 10; $da.IgnorePressure = $true }
  else { $da.Width = $w; $da.Height = $w }
  return $da
}
function Apply-Tool {
  $t = $script:Cfg.tool
  foreach($k in $script:ToolBtns.Keys){ $script:ToolBtns[$k].Background = $(if($k -eq $t -and $script:Draw){ $ACT } else { $IDLE }) }
  if(-not $script:Draw){ $Ink.EditingMode = 'None'; return }
  $Ink.DefaultDrawingAttributes = Make-DA
  if($t -eq 'pen' -or $t -eq 'hl'){ $Ink.EditingMode = 'Ink' }
  elseif($t -eq 'erase'){ $Ink.EditingMode = 'EraseByStroke' }
  else { $Ink.EditingMode = 'None' }   # 도형은 직접 그린다
  Paint-Mini
}
function Set-Mode([bool]$d){
  $script:Draw = $d
  [MkWin]::ClickThrough((Hwnd $ov), (-not $d))
  $Ink.Background = $(if($d){ $script:HitBrush } else { [System.Windows.Media.Brushes]::Transparent })
  $BMode.Content = $(if($d){ '✎ 판서 중' } else { '🖱 조작 중' }); $BMode.Background = $(if($d){ $ACT } else { $ACT2 })
  Apply-Tool; Paint-Mini
}
function Paint-Chips {
  $Chips.Children.Clear()
  foreach($c in $COLORS){
    $b = New-Object System.Windows.Controls.Button; $b.Style = $tb.FindResource('Chip'); $b.Background = To-Brush $c; $b.Tag = $c; $b.ToolTip = $c
    if($c -eq $script:Cfg.color){ $b.BorderBrush = [System.Windows.Media.Brushes]::White; $b.Width = 27; $b.Height = 27 }
    $b.Add_Click({ param($s, $e) Set-Color $s.Tag })
    [void]$Chips.Children.Add($b)
  }
}
function Set-Color([string]$c){ $script:Cfg.color = $c; if($script:Cfg.tool -eq 'erase'){ $script:Cfg.tool = 'pen' }; Paint-Chips; if(-not $script:Draw){ Set-Mode $true } else { Apply-Tool }; Save-Cfg }
function Paint-Toggles {
  $BRing.Background = $(if($script:Cfg.ring){ $ACT2 } else { $IDLE }); $BFade.Background = $(if($script:Cfg.fade){ $ACT2 } else { $IDLE })
  foreach($fb in $FadeSecs.Children){ $fb.Background = $(if($script:Cfg.fade -and [double]$fb.Tag -eq [double]$script:Cfg.fadeSec){ $ACT } else { $IDLE }); $fb.Opacity = $(if($script:Cfg.fade){ 1 } else { 0.55 }) }
  $BNeon.Background = $(if($script:Cfg.neon){ $ACT } else { $IDLE })
  $vis = $(if($script:Cfg.neon){ 'Visible' } else { 'Collapsed' }); $GlowW.Visibility = $vis; $GlowN.Visibility = $vis
  $RingDot.Fill = To-Brush $script:Cfg.ringColor
  $rc = To-Color $script:Cfg.ringColor; $RingE.Stroke = New-Object System.Windows.Media.SolidColorBrush $rc
  $f = [System.Windows.Media.Color]::FromArgb(48, $rc.R, $rc.G, $rc.B); $RingE.Fill = New-Object System.Windows.Media.SolidColorBrush $f; $RingFx.Color = $rc
  if($script:Cfg.ring){ if(-not $ring.IsVisible){ $ring.Show(); [MkWin]::ClickThrough((Hwnd $ring), $true) } } else { $ring.Hide() }
}
function Paint-Mini {
  $c = $(if($script:Draw){ To-Color $script:Cfg.color } else { To-Color '#FF22D3EE' })
  $Glow.Stroke = New-Object System.Windows.Media.SolidColorBrush $c; $GlowFx.Color = $c
  $MiniTx.Text = $(if($script:Draw){ '✎' } else { 'S' }); $MiniTx.FontSize = $(if($script:Draw){ 24 } else { 26 })
}
function Clamp-Win($w){
  $L = [System.Windows.SystemParameters]::VirtualScreenLeft; $T = [System.Windows.SystemParameters]::VirtualScreenTop
  $R = $L + [System.Windows.SystemParameters]::VirtualScreenWidth; $B = $T + [System.Windows.SystemParameters]::VirtualScreenHeight
  $ww = $(if($w.ActualWidth -gt 0){ $w.ActualWidth } else { 300 }); $hh = $(if($w.ActualHeight -gt 0){ $w.ActualHeight } else { 80 })
  $w.Left = [Math]::Max($L, [Math]::Min($w.Left, $R - $ww)); $w.Top = [Math]::Max($T, [Math]::Min($w.Top, $B - $hh))
}
function Cursor-Dip {
  $c = [MkWin]::Cursor(); $p = New-Object System.Windows.Point($c[0], $c[1])
  $src = [System.Windows.PresentationSource]::FromVisual($ov)
  if($src -and $src.CompositionTarget){ $p = $src.CompositionTarget.TransformFromDevice.Transform($p) }
  return $p
}
function Collapse([double]$x = [double]::NaN, [double]$y = [double]::NaN){
  $script:Min = $true; $tb.Hide()
  if(-not [double]::IsNaN($x)){ $mini.Left = $x - 38; $mini.Top = $y - 38 }
  elseif($script:Cfg.mx -gt -9999){ $mini.Left = $script:Cfg.mx; $mini.Top = $script:Cfg.my }
  else { $mini.Left = $tb.Left + 10; $mini.Top = $tb.Top }
  $mini.Show(); [MkWin]::NoActivate((Hwnd $mini)); Clamp-Win $mini; Paint-Mini
}
function Expand { $script:Min = $false; $mini.Hide(); $tb.Show(); Clamp-Win $tb }
function Bring-Here { $p = Cursor-Dip; if($script:Min){ Expand }; $tb.Left = $p.X - 120; $tb.Top = $p.Y + 18; Clamp-Win $tb }

# ── 실행 취소 기록 ──
$Ink.Strokes.Add_StrokesChanged({ param($s, $e)
  if($script:Mute){ return }
  [void]$script:Hist.Add(@{ a = @($e.Added); r = @($e.Removed) })
  $now = [DateTime]::Now
  foreach($st in $e.Added){ $script:Born[$st] = @{ t = $now; c = $st.DrawingAttributes.Color } }
  foreach($st in $e.Removed){ $script:Born.Remove($st) }
  if($script:Hist.Count -gt 300){ $script:Hist.RemoveAt(0) }
})
function Undo {
  if($script:Hist.Count -eq 0){ return }
  $h = $script:Hist[$script:Hist.Count - 1]; $script:Hist.RemoveAt($script:Hist.Count - 1)
  $script:Mute = $true
  foreach($st in $h.a){ if($Ink.Strokes.Contains($st)){ [void]$Ink.Strokes.Remove($st) }; $script:Born.Remove($st) }
  foreach($st in $h.r){ if(-not $Ink.Strokes.Contains($st)){ $Ink.Strokes.Add($st) } }
  $script:Mute = $false
}
function Clear-All { if($Ink.Strokes.Count -gt 0){ $Ink.Strokes.Clear() } }

# ── 도형 (직선 · 화살표 · 곡선 화살표 · 사각 · 원 · 손별표) — 끌기로 그리고 놓으면 획 하나 ──
function Shape-Points([System.Windows.Point]$a, [System.Windows.Point]$b, [string]$t){
  $pts = New-Object System.Windows.Input.StylusPointCollection
  $add = { param($x, $y, $pr = 0.5) $pts.Add((New-Object System.Windows.Input.StylusPoint($x, $y, [single]$pr))) }
  $hl = [Math]::Max(16, [double]$script:Cfg.w * 4)
  if($t -eq 'line'){ & $add $a.X $a.Y; & $add $b.X $b.Y }
  elseif($t -eq 'arrow'){
    $an = [Math]::Atan2($b.Y - $a.Y, $b.X - $a.X)
    & $add $a.X $a.Y; & $add $b.X $b.Y
    & $add ($b.X - $hl * [Math]::Cos($an - 0.45)) ($b.Y - $hl * [Math]::Sin($an - 0.45)); & $add $b.X $b.Y
    & $add ($b.X - $hl * [Math]::Cos($an + 0.45)) ($b.Y - $hl * [Math]::Sin($an + 0.45))
  }
  elseif($t -eq 'curveU' -or $t -eq 'curveD'){
    # 시작→끝을 잇는 2차 곡선 — 가운데가 위(curveU) 또는 아래(curveD)로 휜다 · 머리는 끝의 진행 방향
    $dx = $b.X - $a.X; $dy = $b.Y - $a.Y; $len = [Math]::Sqrt($dx * $dx + $dy * $dy)
    if($len -lt 1){ & $add $a.X $a.Y; & $add $b.X $b.Y; return ,$pts }
    $nx = -$dy / $len; $ny = $dx / $len                       # 수직 방향
    if([Math]::Abs($ny) -lt 0.2){ if($nx -gt 0){ $nx = -$nx; $ny = -$ny } }   # 거의 세로 — 위 곡선은 왼쪽, 아래 곡선은 오른쪽
    elseif($ny -gt 0){ $nx = -$nx; $ny = -$ny }               # 화면 위쪽(-Y)을 향하게
    if($t -eq 'curveD'){ $nx = -$nx; $ny = -$ny }
    $bend = $len * 0.42
    $cx = ($a.X + $b.X) / 2 + $nx * $bend; $cy = ($a.Y + $b.Y) / 2 + $ny * $bend
    $N = 40
    for($i = 0; $i -le $N; $i++){ $u = $i / $N; $v = 1 - $u
      & $add ($v * $v * $a.X + 2 * $v * $u * $cx + $u * $u * $b.X) ($v * $v * $a.Y + 2 * $v * $u * $cy + $u * $u * $b.Y) }
    $an = [Math]::Atan2($b.Y - $cy, $b.X - $cx)
    & $add ($b.X - $hl * [Math]::Cos($an - 0.45)) ($b.Y - $hl * [Math]::Sin($an - 0.45)); & $add $b.X $b.Y
    & $add ($b.X - $hl * [Math]::Cos($an + 0.45)) ($b.Y - $hl * [Math]::Sin($an + 0.45))
  }
  elseif($t -eq 'star'){
    # 손으로 쓱 그린 한붓 별 — 꼭짓점이 살짝 어긋나고 선이 조금 휘며, 마지막 획이 시작점을 지나 삐져나간다 (모양은 끌기 동안 고정)
    $rnd = New-Object System.Random([int]$script:ShapeSeed)
    $cx = ($a.X + $b.X) / 2; $cy = ($a.Y + $b.Y) / 2; $rx = [Math]::Abs($b.X - $a.X) / 2; $ry = [Math]::Abs($b.Y - $a.Y) / 2
    if($rx + $ry -lt 8){ $rx = 22 + [double]$script:Cfg.w * 2; $ry = $rx }   # 톡 누르면 기본 크기
    $r = [Math]::Max($rx, $ry); $tilt = ($rnd.NextDouble() - 0.5) * 0.22
    $V = @(); foreach($k in 0, 2, 4, 1, 3, 0){
      $q = -[Math]::PI / 2 + $tilt + $k * 2 * [Math]::PI / 5
      $j = $(if($V.Count -eq 5){ 0.06 } else { 0 })           # 닫는 점은 시작점에서 살짝 비껴
      $V += , @(($cx + $rx * [Math]::Cos($q) + ($rnd.NextDouble() - 0.5) * $r * (0.08 + $j)), ($cy + $ry * [Math]::Sin($q) + ($rnd.NextDouble() - 0.5) * $r * (0.08 + $j)))
    }
    $M = 14; $tot = 5 * $M; $n = 0
    for($s = 0; $s -lt 5; $s++){
      $p0 = $V[$s]; $p1 = $V[$s + 1]; $sx = $p1[0] - $p0[0]; $sy = $p1[1] - $p0[1]; $sl = [Math]::Max(1, [Math]::Sqrt($sx * $sx + $sy * $sy))
      $bow = ($rnd.NextDouble() - 0.5) * $r * 0.09               # 획마다 살짝 휨
      $last = $(if($s -eq 4){ 1.14 } else { 1 })                 # 마지막 획은 지나쳐 삐져나감
      $from = $(if($s -eq 0){ 0 } else { 1 })
      for($i = $from; $i -le $M; $i++){
        $u = $i / $M * $last; $o = $bow * [Math]::Sin([Math]::PI * [Math]::Min(1, $u))
        $pr = 0.42 + 0.38 * [Math]::Sin([Math]::PI * [Math]::Min(1, $n / $tot))   # 시작·끝은 가늘게
        & $add ($p0[0] + $sx * $u - $sy / $sl * $o) ($p0[1] + $sy * $u + $sx / $sl * $o) $pr; $n++
      }
    }
  }
  elseif($t -eq 'rect'){ & $add $a.X $a.Y; & $add $b.X $a.Y; & $add $b.X $b.Y; & $add $a.X $b.Y; & $add $a.X $a.Y }
  else {
    $cx = ($a.X + $b.X) / 2; $cy = ($a.Y + $b.Y) / 2; $rx = [Math]::Abs($b.X - $a.X) / 2; $ry = [Math]::Abs($b.Y - $a.Y) / 2
    for($i = 0; $i -le 72; $i++){ $q = $i / 72 * 2 * [Math]::PI; & $add ($cx + $rx * [Math]::Cos($q)) ($cy + $ry * [Math]::Sin($q)) }
  }
  return ,$pts
}
function Shape-Stroke([System.Windows.Point]$a, [System.Windows.Point]$b){
  $da = Make-DA; $da.FitToCurve = $false; $da.IgnorePressure = $true
  if($script:Cfg.tool -eq 'star'){ $da.IgnorePressure = $false; $da.Width = $da.Width * 1.35; $da.Height = $da.Height * 1.35 }   # 손글씨처럼 굵기가 변한다
  return New-Object System.Windows.Ink.Stroke((Shape-Points $a $b $script:Cfg.tool), $da)
}
$script:LastL = [DateTime]::MinValue; $script:LastLP = New-Object System.Windows.Point(-99, -99)
$Ink.Add_PreviewMouseLeftButtonDown({ param($s, $e)
  if(-not $script:Draw){ return }
  $p = $e.GetPosition($Ink); $now = [DateTime]::Now
  # 왼쪽 두 번 클릭 — 작은 원으로 (첫 클릭이 남긴 점은 지운다)
  if(($now - $script:LastL).TotalMilliseconds -lt 380 -and [Math]::Abs($p.X - $script:LastLP.X) -lt 8 -and [Math]::Abs($p.Y - $script:LastLP.Y) -lt 8){
    $script:LastL = [DateTime]::MinValue
    $script:Mute = $true
    foreach($st in @($Ink.Strokes)){ $bd = $st.GetBounds(); $bn = $script:Born[$st]; if($bn -and ($now - $bn.t).TotalMilliseconds -lt 900 -and $bd.Width -lt 14 -and $bd.Height -lt 14){ [void]$Ink.Strokes.Remove($st); $script:Born.Remove($st) } }
    if($script:TapStar -and $Ink.Strokes.Contains($script:TapStar)){ [void]$Ink.Strokes.Remove($script:TapStar); $script:Born.Remove($script:TapStar) }   # 별표 도구로 두 번 누른 경우 첫 별은 지운다
    $script:TapStar = $null
    $script:Mute = $false
    $sp = $ov.PointToScreen($p); $src = [System.Windows.PresentationSource]::FromVisual($ov); if($src){ $sp = $src.CompositionTarget.TransformFromDevice.Transform($sp) }
    Collapse $sp.X $sp.Y; $e.Handled = $true; return
  }
  $script:LastL = $now; $script:LastLP = $p
  $t = $script:Cfg.tool
  if($SHAPES -contains $t){
    $script:ShapeSeed = Get-Random -Maximum 2147483647; $script:ShapeStart = $p; $script:Mute = $true; $script:Shape = Shape-Stroke $p $p; $Ink.Strokes.Add($script:Shape); $script:Mute = $false
    [void]$Ink.CaptureMouse(); $e.Handled = $true
  }
})
$Ink.Add_PreviewMouseMove({ param($s, $e)
  if($null -eq $script:Shape){ return }
  $p = $e.GetPosition($Ink); $script:Mute = $true
  [void]$Ink.Strokes.Remove($script:Shape); $script:Shape = Shape-Stroke $script:ShapeStart $p; $Ink.Strokes.Add($script:Shape)
  $script:Mute = $false
})
$Ink.Add_PreviewMouseLeftButtonUp({ param($s, $e)
  if($null -eq $script:Shape){ return }
  $Ink.ReleaseMouseCapture(); $st = $script:Shape; $script:Shape = $null
  $up = $e.GetPosition($Ink); $script:TapStar = $(if($script:Cfg.tool -eq 'star' -and [Math]::Abs($up.X - $script:ShapeStart.X) + [Math]::Abs($up.Y - $script:ShapeStart.Y) -lt 6){ $st } else { $null })
  $script:Mute = $true; [void]$Ink.Strokes.Remove($st); $script:Mute = $false
  $bd = $st.GetBounds(); if($bd.Width + $bd.Height -gt 6){ $Ink.Strokes.Add($st) }   # 기록에 남는다 (손별표는 톡 눌러도 기본 크기로 남음)
})

# ── 도구줄 단추 ──
foreach($k in @($script:ToolBtns.Keys)){ $script:ToolBtns[$k].Add_Click({ param($s, $e) $script:Cfg.tool = $s.Tag; if(-not $script:Draw){ Set-Mode $true } else { Apply-Tool }; Save-Cfg }) }
$BMode.Add_Click({ Set-Mode (-not $script:Draw) })
# 전체 색상 창 — 덮개(맨 위 · 판서 때 클릭을 받음) 아래에 깔리지 않게: 잠시 클릭 통과 + 도구줄을 주인으로
function Pick-Color([string]$start){
  $d = New-Object System.Windows.Forms.ColorDialog; $d.FullOpen = $true; $d.AnyColor = $true
  $c = To-Color $start; $d.Color = [System.Drawing.Color]::FromArgb($c.R, $c.G, $c.B)
  [MkWin]::ClickThrough((Hwnd $ov), $true)
  $own = New-Object System.Windows.Forms.NativeWindow; $own.AssignHandle((Hwnd $tb))
  try{ $r = $d.ShowDialog($own) } finally { $own.ReleaseHandle(); [MkWin]::ClickThrough((Hwnd $ov), (-not $script:Draw)) }
  if($r -eq 'OK'){ return ('#FF{0:X2}{1:X2}{2:X2}' -f $d.Color.R, $d.Color.G, $d.Color.B) }
  return $null
}
$BAll.Add_Click({ $v = Pick-Color $script:Cfg.color; if($v){ Set-Color $v } })
$SW.Value = [double]$script:Cfg.w; $WTxt.Text = '굵기 ' + $script:Cfg.w
$SW.Add_ValueChanged({ $script:Cfg.w = [int]$SW.Value; $WTxt.Text = '굵기 ' + $script:Cfg.w; Apply-Tool; Save-Cfg })
$BRing.Add_Click({ $script:Cfg.ring = -not $script:Cfg.ring; Paint-Toggles; Save-Cfg })
$BRingC.Add_Click({ $v = Pick-Color $script:Cfg.ringColor; if($v){ $script:Cfg.ringColor = $v; $script:Cfg.ring = $true; Paint-Toggles; Save-Cfg } })
$BFade.Add_Click({ $script:Cfg.fade = -not $script:Cfg.fade; Paint-Toggles; Save-Cfg; Say($(if($script:Cfg.fade){ '⏳ 프레젠테이션 모드 — 그린 것이 ' + $script:Cfg.fadeSec + '초 뒤 사라집니다' } else { '프레젠테이션 모드 끔 — 그린 것이 남습니다' })) })
foreach($fb in $FadeSecs.Children){ $fb.Add_Click({ param($s2, $e2) $script:Cfg.fadeSec = [double]$s2.Tag; $script:Cfg.fade = $true; Paint-Toggles; Save-Cfg; Say('⏳ 프레젠테이션 모드 — ' + $script:Cfg.fadeSec + '초 뒤 사라집니다') }) }
$BNeon.Add_Click({ $script:Cfg.neon = -not $script:Cfg.neon; Paint-Toggles; Save-Cfg; Say($(if($script:Cfg.neon){ '✨ 네온 — 그린 선이 제 색으로 빛납니다' } else { '네온 끔' })) })
$BUndo.Add_Click({ Undo })
$BClear.Add_Click({ Clear-All })
$BMin.Add_Click({ Collapse })
$BExit.Add_Click({ Quit })
$BPng.Add_Click({
  $tb.Hide(); $ring.Hide()
  $tb.Dispatcher.Invoke([Action]{}, [System.Windows.Threading.DispatcherPriority]::Render)
  Start-Sleep -Milliseconds 180
  try{
    $vs = [System.Windows.Forms.SystemInformation]::VirtualScreen
    $bmp = New-Object System.Drawing.Bitmap($vs.Width, $vs.Height); $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.CopyFromScreen($vs.Left, $vs.Top, 0, 0, $bmp.Size); $g.Dispose()
    $dir = Join-Path ([Environment]::GetFolderPath('MyPictures')) 'S포인터'; if(-not (Test-Path $dir)){ New-Item -ItemType Directory -Path $dir | Out-Null }
    $f = Join-Path $dir ((Get-Date).ToString('yyyyMMdd_HHmmss') + '.png'); $bmp.Save($f, [System.Drawing.Imaging.ImageFormat]::Png); $bmp.Dispose()
    $msg = '저장했습니다 — 사진\S포인터\' + (Split-Path $f -Leaf)
  }catch{ $msg = 'PNG 저장 실패: ' + $_.Exception.Message }
  $tb.Show(); if($script:Cfg.ring){ $ring.Show() }; Say $msg
})
$Grip.Add_MouseLeftButtonDown({ try{ $tb.DragMove() }catch{}; Clamp-Win $tb; $script:Cfg.bx = $tb.Left; $script:Cfg.by = $tb.Top; Save-Cfg })
$mini.Add_MouseLeftButtonDown({
  $l = $mini.Left; $t = $mini.Top
  try{ $mini.DragMove() }catch{}
  if([Math]::Abs($mini.Left - $l) + [Math]::Abs($mini.Top - $t) -lt 4){ Expand } else { Clamp-Win $mini; $script:Cfg.mx = $mini.Left; $script:Cfg.my = $mini.Top; Save-Cfg }
})

# ── 트레이 아이콘 (도구줄을 잃어버려도 여기서) ──
$tray = New-Object System.Windows.Forms.NotifyIcon
$tray.Icon = [System.Drawing.SystemIcons]::Information; $tray.Text = 'S포인터'; $tray.Visible = $true
$menu = New-Object System.Windows.Forms.ContextMenuStrip
[void]$menu.Items.Add('도구줄 보이기', $null, { Bring-Here })
[void]$menu.Items.Add('판서 ↔ 조작', $null, { Set-Mode (-not $script:Draw) })
[void]$menu.Items.Add('전체 지우기', $null, { Clear-All })
# 오른쪽 3번 클릭으로 켜기 — 감시 프로그램(S-Pointer-Watch.ps1)을 시작프로그램에 넣고/빼고, 바로 켜고/끈다
$script:WatchLnk = Join-Path ([Environment]::GetFolderPath('Startup')) 'S포인터 오른쪽3번.lnk'
$script:RunVbs = Join-Path $PSScriptRoot 'S포인터 실행.vbs'
$miWatch = New-Object System.Windows.Forms.ToolStripMenuItem('오른쪽 3번 클릭으로 켜기')
$miWatch.Checked = (Test-Path $script:WatchLnk)
$miWatch.Add_Click({
  try{
    if(Test-Path $script:WatchLnk){
      Remove-Item $script:WatchLnk -Force
      Start-Process 'wscript.exe' -ArgumentList ('"' + $script:RunVbs + '" unwatch')
      $miWatch.Checked = $false; Say '오른쪽 3번 클릭으로 켜기 — 끔'
    } else {
      $ws = New-Object -ComObject WScript.Shell; $l = $ws.CreateShortcut($script:WatchLnk)
      $l.TargetPath = 'wscript.exe'; $l.Arguments = '"' + $script:RunVbs + '" watch'; $l.WorkingDirectory = $PSScriptRoot; $l.Description = 'S포인터 — 오른쪽 3번 클릭으로 켜기 (감시)'; $l.Save()
      Start-Process 'wscript.exe' -ArgumentList ('"' + $script:RunVbs + '" watch')
      $miWatch.Checked = $true; Say '오른쪽 3번 클릭으로 켜기 — 켬 (꺼져 있을 때 오른쪽 빠르게 3번)'
    }
  }catch{ Say ('설정 실패: ' + $_.Exception.Message) }
})
[void]$menu.Items.Add('-')
[void]$menu.Items.Add($miWatch)
[void]$menu.Items.Add('-')
[void]$menu.Items.Add('끝내기', $null, { Quit })
$tray.ContextMenuStrip = $menu
$tray.Add_MouseDoubleClick({ Bring-Here })

# ── 16ms 마다 — 커서 링 · 오른쪽 두 번 클릭 · 단축키 · 프레젠테이션 모드 ──
$script:Prev = @{}; $script:LastR = [DateTime]::MinValue; $script:TipAt = [DateTime]::MinValue; $script:FlagAt = [DateTime]::MinValue
$script:LCount = 0; $script:LAt = [DateTime]::MinValue; $script:LXY = @(-9999, -9999)
function In-Win($w, $p){ return ($w.IsVisible -and $p.X -ge $w.Left -and $p.X -le $w.Left + $w.ActualWidth -and $p.Y -ge $w.Top -and $p.Y -le $w.Top + $w.ActualHeight) }
function Edge([int]$k){ $d = [MkWin]::Down($k); $was = [bool]$script:Prev[$k]; $script:Prev[$k] = $d; return ($d -and -not $was) }
$timer = New-Object System.Windows.Threading.DispatcherTimer
$timer.Interval = [TimeSpan]::FromMilliseconds(16)
$timer.Add_Tick({
  try{
    $now = [DateTime]::Now
    if($script:Cfg.ring){
      $p = Cursor-Dip; $ring.Left = $p.X - 32; $ring.Top = $p.Y - 32
      $dn = [MkWin]::Down(1); $sz = $(if($dn){ 30 } else { 44 }); if($RingE.Width -ne $sz){ $RingE.Width = $sz; $RingE.Height = $sz }
    }
    if(Edge 1){   # 왼쪽 단추 — 같은 자리에서 빠르게 4번 = 끝내기 (도구줄 · 작은 원 위 클릭은 세지 않음)
      $c = [MkWin]::Cursor(); $pd = Cursor-Dip
      if((In-Win $tb $pd) -or (In-Win $mini $pd)){ $script:LCount = 0 }
      else {
        if(($now - $script:LAt).TotalMilliseconds -lt 400 -and [Math]::Abs($c[0] - $script:LXY[0]) -lt 16 -and [Math]::Abs($c[1] - $script:LXY[1]) -lt 16){ $script:LCount++ } else { $script:LCount = 1 }
        $script:LAt = $now; $script:LXY = $c
        if($script:LCount -ge 4){ Quit; return }
      }
    }
    if(Edge 2){   # 오른쪽 단추
      if(($now - $script:LastR).TotalMilliseconds -lt 420){ $script:LastR = [DateTime]::MinValue; Set-Mode (-not $script:Draw); Say($(if($script:Draw){ '✎ 판서 — 화면 위에 그립니다' } else { '🖱 조작 — 화면을 그대로 누를 수 있습니다' })) }
      else { $script:LastR = $now }
    }
    $cs = [MkWin]::Down(0x11) -and [MkWin]::Down(0x10)
    if((Edge 0x58) -and $cs){ Set-Mode (-not $script:Draw) }
    if((Edge 0x5A) -and $cs){ Undo }
    if((Edge 0x43) -and $cs){ Clear-All }
    if((Edge 0x4D) -and $cs){ Bring-Here }
    if((Edge 0x51) -and $cs){ Quit; return }
    if((Edge 0x1B) -and $script:Draw){ Set-Mode $false }
    if($script:Cfg.fade -and $script:Born.Count -gt 0 -and $null -eq $script:Shape){
      $script:Mute = $true
      foreach($st in @($script:Born.Keys)){
        $b = $script:Born[$st]; $age = ($now - $b.t).TotalMilliseconds
        $hold = [double]$script:Cfg.fadeSec * 1000; $fd = [Math]::Min(800, $hold)   # 0.5S 는 흐려지는 것도 0.5초
        if($age -gt $hold + $fd){ if($Ink.Strokes.Contains($st)){ [void]$Ink.Strokes.Remove($st) }; $script:Born.Remove($st) }
        elseif($age -gt $hold){ $a = [byte]([Math]::Max(0, [Math]::Min(255, $b.c.A * (1 - ($age - $hold) / $fd)))); $st.DrawingAttributes.Color = [System.Windows.Media.Color]::FromArgb($a, $b.c.R, $b.c.G, $b.c.B) }
      }
      $script:Mute = $false
    }
    # SJRWS 도구의 ▶ 켜기 / ■ 끄기 (spointer:// → 실행 파일이 표시 파일을 남김) — 0.5초마다 확인
    if(($now - $script:FlagAt).TotalMilliseconds -gt 500){
      $script:FlagAt = $now
      $qf = Join-Path $script:FlagDir 'quit.flag'; $sf = Join-Path $script:FlagDir 'show.flag'
      if(Test-Path $qf){ Remove-Item $qf -ErrorAction SilentlyContinue; Quit; return }
      if(Test-Path $sf){ Remove-Item $sf -ErrorAction SilentlyContinue; Bring-Here; Say 'S포인터가 이미 켜져 있습니다' }
    }
    if($script:TipAt -ne [DateTime]::MinValue -and ($now - $script:TipAt).TotalSeconds -gt 4){ $script:TipAt = [DateTime]::MinValue; $Tip.Foreground = To-Brush '#FF8A90A5'; $Tip.Text = '오른쪽 두 번 클릭 = 판서 ↔ 조작 · 판서 중 왼쪽 두 번 클릭 = 작게 · 왼쪽 네 번 클릭 = 끝내기' }
  }catch{}
})

function Quit {
  try{ $timer.Stop() }catch{}
  if($tb.IsVisible){ $script:Cfg.bx = $tb.Left; $script:Cfg.by = $tb.Top }
  Save-Cfg
  try{ $tray.Visible = $false; $tray.Dispose() }catch{}
  try{ $script:Mtx.ReleaseMutex() }catch{}
  [System.Windows.Application]::Current.Shutdown()
}

# ── 시작 ──
$app = New-Object System.Windows.Application
$app.ShutdownMode = 'OnExplicitShutdown'
$ov.Show(); [MkWin]::ClickThrough((Hwnd $ov), $true)
$tb.Owner = $ov; $mini.Owner = $ov; $ring.Owner = $ov   # 덮개보다 늘 위 (덮개를 띄운 뒤에야 정할 수 있다)
$tb.Show(); [MkWin]::NoActivate((Hwnd $tb))
if($script:Cfg.bx -gt -9999){ $tb.Left = $script:Cfg.bx; $tb.Top = $script:Cfg.by }
else { $wa = [System.Windows.SystemParameters]::WorkArea; $tb.Left = $wa.Left + ($wa.Width - $tb.ActualWidth) / 2; $tb.Top = $wa.Top + 6 }
Clamp-Win $tb
Paint-Chips; Paint-Toggles; Set-Mode $false; Paint-Mini
$timer.Start()
Say 'S포인터 — 오른쪽 두 번 클릭으로 판서를 시작하세요'
[void]$app.Run()
