﻿<#
  S포인터 감시 (v1.4 · 2026-10-11) — 송도제일 SJRWS
  S포인터가 꺼져 있을 때 오른쪽 단추를 같은 자리에서 빠르게 3번 누르면 S포인터를 켭니다.
  · Windows 시작 때 함께 켜짐 (시작프로그램 「S포인터 오른쪽3번.lnk」) — 화면에 보이지 않음
  · 마우스 신호만 받아 보고 그대로 넘김 (다른 프로그램 동작은 그대로) · 기다리는 동안 CPU 거의 0
  · S포인터가 이미 켜져 있으면 아무것도 하지 않음 (S포인터 안에서는 오른쪽 2번 = 판서 ↔ 조작 그대로)
  · 끄기: S포인터 트레이 아이콘 → 「오른쪽 3번 클릭으로 켜기」 끄기, 또는 설치 파일을 다시 실행해 「아니요」
#>
$FlagDir = Join-Path $env:APPDATA 'S-Pointer'
if(-not (Test-Path $FlagDir)){ New-Item -ItemType Directory -Path $FlagDir | Out-Null }
$Mtx = New-Object System.Threading.Mutex($false, 'Local\S_Pointer_Watch')
if(-not $Mtx.WaitOne(0)){ exit }   # 이미 감시 중
Remove-Item (Join-Path $FlagDir 'watch_quit.flag') -ErrorAction SilentlyContinue

Add-Type -ReferencedAssemblies System.Windows.Forms -TypeDefinition @'
using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;
public static class SPWatch {
  delegate IntPtr LLProc(int n, IntPtr w, IntPtr l);
  [StructLayout(LayoutKind.Sequential)] struct MSLL { public int x; public int y; public uint data; public uint flags; public uint time; public IntPtr extra; }
  [DllImport("user32.dll", SetLastError = true)] static extern IntPtr SetWindowsHookEx(int id, LLProc fn, IntPtr mod, uint tid);
  [DllImport("user32.dll")] static extern IntPtr CallNextHookEx(IntPtr h, int n, IntPtr w, IntPtr l);
  [DllImport("user32.dll")] static extern bool UnhookWindowsHookEx(IntPtr h);
  [DllImport("kernel32.dll", CharSet = CharSet.Unicode)] static extern IntPtr GetModuleHandle(string n);
  static LLProc keep; static IntPtr hook = IntPtr.Zero;
  static int cnt = 0; static uint lastT = 0; static int lx = -99999, ly = -99999;
  static DateTime quiet = DateTime.MinValue;
  public static string Vbs = "", FlagDir = "";
  static IntPtr Proc(int n, IntPtr w, IntPtr l) {
    try {
      if (n >= 0 && w.ToInt32() == 0x0204) {            // 오른쪽 단추 눌림
        MSLL m = (MSLL)Marshal.PtrToStructure(l, typeof(MSLL));
        if ((m.flags & 1) == 0) {                       // 프로그램이 흉내 낸 클릭은 제외
          bool near = Math.Abs(m.x - lx) < 16 && Math.Abs(m.y - ly) < 16;
          if (cnt > 0 && near && unchecked(m.time - lastT) < 450) cnt++; else cnt = 1;
          lastT = m.time; lx = m.x; ly = m.y;
          if (cnt >= 3) { cnt = 0; Fire(); }
        }
      }
    } catch { }
    return CallNextHookEx(hook, n, w, l);
  }
  static bool Running() {
    Mutex m;
    if (Mutex.TryOpenExisting(@"Local\S_Pointer_SJRWS", out m)) { m.Dispose(); return true; }
    return false;
  }
  static void Fire() {
    if (DateTime.Now < quiet) return;
    quiet = DateTime.Now.AddSeconds(3);
    if (Running()) return;
    try { Process.Start("wscript.exe", "\"" + Vbs + "\""); } catch { }
  }
  public static void Run() {
    keep = new LLProc(Proc);
    hook = SetWindowsHookEx(14, keep, GetModuleHandle(null), 0);   // WH_MOUSE_LL
    System.Windows.Forms.Timer t = new System.Windows.Forms.Timer();
    t.Interval = 1000;
    t.Tick += delegate(object s, EventArgs e) {
      string q = Path.Combine(FlagDir, "watch_quit.flag");
      if (File.Exists(q)) { try { File.Delete(q); } catch { } t.Stop(); Application.ExitThread(); }
    };
    t.Start();
    Application.Run();
    if (hook != IntPtr.Zero) UnhookWindowsHookEx(hook);
  }
}
'@
[SPWatch]::Vbs = Join-Path $PSScriptRoot 'S포인터 실행.vbs'
[SPWatch]::FlagDir = $FlagDir
[SPWatch]::Run()
try{ $Mtx.ReleaseMutex() }catch{}
